<?php
$db=new mysqli("localhost","root","123","laoleiphp");
$db->set_charset("utf8");
if($db->connect_errno){
    echo "数据库连接出错";
    exit();
}
?>