<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>留言板</title>
		<meta name="viewport" content="width=device-width,initial-scale=1, maximum-scale=1" />
		<link href="tpl/css/app.css" rel="stylesheet" />
	</head>
	<body>
		<div class="main">
			<div class="nav">
				<a href="guest.php">留言首页</a>
				<a class="active" href="guest.php?a=add">我要留言</a>
			</div>
            <div>
                留言回复成功。
            </div>

		</div>
	</body>
</html>
