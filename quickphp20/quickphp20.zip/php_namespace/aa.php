<?php
namespace aa;
function myaa(){
    echo "myaa";
}