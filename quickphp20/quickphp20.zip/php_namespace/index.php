<?php
namespace index;
use \dd\cc;
require "aa.php";
require "index.bb.php";
require "dd.cc.php";
echo \aa\myaa();
echo bb\mybb();
echo cc\mycc();