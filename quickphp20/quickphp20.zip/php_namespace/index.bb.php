<?php
namespace index\bb;
function mybb(){
    echo "mybb";
}