<?php
namespace dd\cc;
function mycc(){
    echo "mycc";
}