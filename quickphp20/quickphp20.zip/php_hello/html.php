<!DOCTYPE html>
<html>
	<head>
		<title>php</title>
	</head>
	<body>
		<div>php是可以同html混合使用的</div>
		<?php 
			echo "html php ";
			$a='$a是变量';
		?>
		<div><?=$a?></div>
		<?php 
			echo "第三段PHP代码";
		?>
	</body>
</html>