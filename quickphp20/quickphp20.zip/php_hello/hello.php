<?php
/*php 
首个程序*/
//单行文本注释
echo "Hi,PHP";
echo 'Hi,PHP 单引号';
?>