<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>BBS</title>
		<meta name="viewport" content="width=device-width,initial-scale=1, maximum-scale=1" />
		<link href="tpl/css/app.css" rel="stylesheet" />
	</head>
	<body>
		<div class="main">
			<div class="nav">
				<a href="bbs.php">首页</a>
				 
			</div>
            <div>
               <?=$msg?>
            </div>

		</div>
	</body>
</html>
