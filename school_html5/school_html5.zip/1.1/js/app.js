document.querySelector("#clickMe").addEventListener("click",function(e){
	this.innerHTML="我被点击了"+Math.random();
})